from django.shortcuts import render

from .models import User
from django.http import HttpResponse, JsonResponse
from random import randint
# Create your views here.


def index(req):
    # add()
    # delete()
    # update()
    return JsonResponse({'res': showAll()})

    return HttpResponse('<h1>Hello ORM</h1>')

# ORM方式操作数据库 不需要sql语句


def showAll():
    u = User.objects.all()
    # values(): 是结果中的值, 转 list 数组类型进行展示
    return list(u.values())


def update():
    # 修改 id=2 的数据项,  名字:东东  年龄30
    u = User.objects.get(id=2)
    u.name = '东东'
    u.age = 30

    u.save()  # 保存修改


def delete():
    # 删除id=1的数据
    u = User.objects.get(id=1)
    # objects: 代表所有数据
    # get: 相当于where语句
    u.delete()
    # 删除方法


def add():
    name = '王%s' % randint(10, 99)
    age = randint(10, 99)
    phone = '188%s' % randint(1e7, 9e7)
    email = '%s@qq.com' % randint(1e6, 9e10)
    gender = randint(0, 2)

    # 参数结构:  字段名=值
    u = User(name=name, age=age, phone=phone, email=email, gender=gender)
    u.save()  # 保存
