from django.db import models

# Create your models here.

# ORM 对象关系映射
'''
程序员发现 面向对象写法 和 表结构非常相似

表名           类名
表字段         类属性
表数据         实例化对象

例如: 用户表 User
CREATE TABLE IF NOT EXISTS user(
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    age TINYINT UNSIGNED NOT NULL,
    phone CHAR(11) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    gender TINYINT UNSIGNED NOT NULL,
) CHARSET=utf8
'''

# 实现表->类的转化


class User(models.Model):
    # 必须继承父类, 才是合格的ORM类
    # id: 由于主键是必备的, 所以父类中已经默认具备此属性. 子类无需书写
    name = models.CharField(max_length=255, null=False)
    # 数字类型 都自带无符号特性
    age = models.SmallIntegerField(null=False)
    phone = models.CharField(max_length=11, null=False)
    email = models.CharField(max_length=255, null=False)
    gender = models.SmallIntegerField(null=False)


'''
需要通过 django 提供的命令, 让 ORM 参考 User 类 生成对应的表

$ 是linux的风格, 代表接下来的是命令行

检测是否有 ORM 类变更
$ py manage.py makemigrations

把检测的变更应用到数据库
$ py manage.py migrate

'''
